/**
 * Contains classes needed to connect to the back end directly.
 */
package teammates.client.remoteapi;
