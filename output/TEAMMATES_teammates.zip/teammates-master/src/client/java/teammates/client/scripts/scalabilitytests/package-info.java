/**
 * Contains scalability and performance tests.
 */
package teammates.client.scripts.scalabilitytests;
