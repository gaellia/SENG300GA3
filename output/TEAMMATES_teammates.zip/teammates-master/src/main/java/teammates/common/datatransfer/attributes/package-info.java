/**
 * Contains attributes classes as a wrapper for persistable entities.
 */
package teammates.common.datatransfer.attributes;
