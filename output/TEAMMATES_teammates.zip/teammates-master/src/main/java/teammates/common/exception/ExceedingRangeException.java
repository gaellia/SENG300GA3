package teammates.common.exception;

@SuppressWarnings("serial")
public class ExceedingRangeException extends Exception {
    public ExceedingRangeException(String message) {
        super(message);
    }

}
