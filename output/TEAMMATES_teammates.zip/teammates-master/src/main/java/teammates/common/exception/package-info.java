/**
 * Contains custom exceptions used across the application.
 */
package teammates.common.exception;
