package teammates.common.util;

public enum RecipientType {
    INSTRUCTOR,
    STUDENT,
    TEAM
}
