/**
 * Contains classes that represent persistable entities.
 */
package teammates.storage.entity;
