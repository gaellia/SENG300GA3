/**
 * Contains lightweight data transfer objects for transferring data
 * between a controller class and a view model class.
 */
package teammates.ui.datatransfer;
