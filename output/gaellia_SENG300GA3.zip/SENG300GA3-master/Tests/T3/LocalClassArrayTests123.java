package T3;

public class LocalClassArrayTests123 {
	
	public void m() {
		class Local {}
		
		Local[][] l; 
	}

}
