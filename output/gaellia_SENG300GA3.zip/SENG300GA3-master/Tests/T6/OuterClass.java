package T6; 

public class OuterClass { 
	class InnerClass {} 
	interface InnerInterface {} 
	enum InnerEnum {} 
	@interface InnerAnnote {} 
}