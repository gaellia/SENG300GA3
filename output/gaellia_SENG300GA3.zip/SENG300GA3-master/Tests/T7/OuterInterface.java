package T7;

public interface OuterInterface {
	class InnerClass {}
	interface InnerInterface {}
	enum InnerEnum {}
	@interface InnerAnnote {}
}