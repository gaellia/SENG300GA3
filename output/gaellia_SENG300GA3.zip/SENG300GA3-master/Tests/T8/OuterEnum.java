package T8;

public enum OuterEnum {;
	class InnerClass {}
	interface InnerInterface {}
	enum InnerEnum {}
	@interface InnerAnnote {}
}