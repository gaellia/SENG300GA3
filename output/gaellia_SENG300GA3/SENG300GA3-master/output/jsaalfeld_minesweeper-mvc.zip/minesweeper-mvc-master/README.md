# minesweeper-mvc

[![Build Status](https://travis-ci.org/jsaalfeld/minesweeper-mvc.svg)](https://travis-ci.org/jsaalfeld/minesweeper-mvc)

Simple Minesweeper with GUI written in Java with the MVC-Pattern