/*
 * Copyright (c) 2007 Mockito contributors
 * This program is made available under the terms of the MIT License.
 */

/**
 * JUnit integration to provide better support for junit runners in IDEs.
 */
package org.mockito.exceptions.verification.junit;
