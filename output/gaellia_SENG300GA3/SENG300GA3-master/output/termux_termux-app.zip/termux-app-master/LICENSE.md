Released under [the GPLv3 license](https://www.gnu.org/licenses/gpl.html).

Contains code from `Terminal Emulator for Android` by which is released under [the Apache License 2.0](https://www.apache.org/licenses/).
