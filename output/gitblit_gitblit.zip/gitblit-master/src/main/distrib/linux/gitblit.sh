#!/bin/bash
java -jar gitblit.jar --baseFolder data
