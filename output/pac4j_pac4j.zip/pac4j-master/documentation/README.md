## *pac4j* documentation

This documentation will be used for the *pac4j* website: [www.pac4j.org](http://www.pac4j.org).

You can browse it locally at `http://localhost:4000` by running: `bundle exec jekyll serve`.

Any changes made on the files will be seen immediately.
