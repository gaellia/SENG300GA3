---
layout: homeblog
title: <i class="fa fa-info-circle" aria-hidden="true"></i> Blog
---

## &bull; January 2018: [Spring Boot Security: choose spring-webmvc-pac4j over Spring Security](/blog/spring-boot-security-choose-spring-webmvc-pac4j.html)

## &bull; September 2017: [Yet another JWT library (pac4j-jwt) for Java](/blog/yet-another-jwt-library-pac4j-jwt-for-java.html)
