---
layout: alldoc
title: <i class="fa fa-user" aria-hidden="true"></i> All <i>pac4j</i> engine/core documentations&#58;
---

<div class="text-center">

<h1 id="v3.0"><a href="index.html">v3.0</a> <small>(MAJOR)</small></h1>

<h1><a id="v2.2" href="http://www.pac4j.org/2.2.x/docs/index.html">v2.2</a> <small>(MINOR)</small> <a id="v2.1" href="http://www.pac4j.org/2.1.x/docs/index.html">v2.1</a> <small>(MINOR)</small> <a id="v2.0" href="http://www.pac4j.org/2.0.x/docs/index.html">v2.0</a> <small>(MAJOR)</small></h1>

<h1 id="v1.9"><a href="http://www.pac4j.org/1.9.x/docs/index.html">v1.9</a> <small>(MAJOR)</small></h1>

</div>
