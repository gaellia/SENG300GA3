---
layout: doc
title: The big picture
---

<div class="text-center">

<img width="980" src="/img/pac4j.png" />

</div>
