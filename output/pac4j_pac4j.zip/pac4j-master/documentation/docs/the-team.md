---
layout: ddoc
title: The Team
---

## The Creator

<div class="bio">
    <div><a href="https://github.com/leleuj"><img src="https://avatars3.githubusercontent.com/u/1038508?s=100" /></a></div>
    <div><i>Jérôme Leleu</i><br />&#9656; Project leader, core committer, maintainer of many pac4j implementations: J2E, Spring MVC, Shiro, Spring Security, Play...</div>
</div>
<div class="clear"></div>

## The Committers

<div class="bio">
    <div><a href="https://github.com/mmoayyed"><img src="https://avatars1.githubusercontent.com/u/1205228?s=100" /></a></div>
    <div><i>Misagh Moayyed</i><br />&#9656; Core committer, Chairman of the CAS project</div>
</div>
<div class="clear"></div>

<div class="bio">
    <div><a href="https://github.com/millross"><img src="https://avatars2.githubusercontent.com/u/1318862?s=100" /></a></div>
    <div><i>Jez Prime</i><br />&#9656; Core committer, Vert.x maintainer</div>
</div>
<div class="clear"></div>

<div class="bio">
    <div><a href="https://github.com/victornoel"><img src="https://avatars2.githubusercontent.com/u/160975?s=100" /></a></div>
    <div><i>Victor Noël</i><br />&#9656; Core committer, Dropwizard and JAX-RS maintainer</div>
</div>
<div class="clear"></div>

<div class="bio">
    <div><a href="https://github.com/ldaley"><img src="https://avatars3.githubusercontent.com/u/17825?s=100" /></a></div>
    <div><i>Luke Daley</i><br />&#9656; Ratpack maintainer</div>
</div>
<div class="clear"></div>

<div class="bio">
    <div><a href="https://github.com/miremond"><img src="https://avatars1.githubusercontent.com/u/5079621?s=100" /></a></div>
    <div><i>Michaël Remond</i><br />&#9656; Inactive committer</div>
</div>
<div class="clear"></div>
