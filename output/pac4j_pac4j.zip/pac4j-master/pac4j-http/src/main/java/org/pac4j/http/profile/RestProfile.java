package org.pac4j.http.profile;

import org.pac4j.core.profile.CommonProfile;

/**
 * REST profile.
 *
 * @author Jerome Leleu
 * @since 2.1.0
 */
public class RestProfile extends CommonProfile {
}
