# Version 0.3.0 


* __Feature required in #73 (#77)__: Added `charsCount` function

    [César Aguilera](mailto:cesar.aguilera.p@gmail.com) - Tue, 9 May 2017 18:16:11 +0530

    ​

* __fixed bug in containsAll (#76)__

    [wli75](mailto:wli75@illinois.edu) - Tue, 7 Mar 2017 20:09:18 +0530

    ​

* __Resolved #66__: Added `trimEnd` function

    [Shekhar Gulati](mailto:shekhargulati84@gmail.com) - Wed, 24 Aug 2016 15:32:45 +0530

    ​

* __Resolved #65__: Added `trimStart`function

    [Shekhar Gulati](mailto:shekhargulati84@gmail.com) - Wed, 24 Aug 2016 15:02:00 +0530

    ​

* __Resolved #68__: Added `upperFirst` function

    [Shekhar Gulati](mailto:shekhargulati84@gmail.com) - Wed, 24 Aug 2016 14:26:16 +0530

    ​

* __Resolved #69__: Added `words` function

    [Shekhar Gulati](mailto:shekhargulati84@gmail.com) - Wed, 24 Aug 2016 12:56:18 +0530

    ​

* __Resolved#71__: Added `isEnclosedBetween` function

    [Shekhar Gulati](mailto:shekhargulati84@gmail.com) - Wed, 24 Aug 2016 12:11:04 +0530

    ​

* __Resolved #54 and Resolved #59__: Added `capitalize` and `lowerFirst` functions

    [Shekhar Gulati](mailto:shekhargulati84@gmail.com) - Wed, 27 Jul 2016 23:19:41 +0530

    ​

* __Resolved #53__: Added `join` function

    [Shekhar Gulati](mailto:shekhargulati84@gmail.com) - Mon, 25 Jul 2016 15:29:43 +0530

    ​

* __Simplify Maven and Gradle configuration (#70)__

    [Marcin Zajączkowski](mailto:mszpak@wp.pl) - Tue, 19 Jul 2016 20:58:57 +0530



